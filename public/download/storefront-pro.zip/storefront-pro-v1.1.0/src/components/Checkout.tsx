'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState, useTransition } from 'react';
import { checkout, checkoutQuote } from '@/app/actions';
import { COUNTRIES } from '@/lib/shipping';
import { formatAmount, type Currency } from '@/lib/money';
import Art from './Art';
import { useStore } from './StoreProvider';

type Q = Awaited<ReturnType<typeof checkoutQuote>>;
const FIELDS = ['name', 'email', 'phone', 'country', 'address', 'city', 'zip', 'state'] as const;
type Form = Record<(typeof FIELDS)[number], string>;
// Country from the visitor's IP (pm-cc cookie set by the proxy), else from the time zone.
const guessCountry = () => {
  const cc = document.cookie.match(/(?:^|; )pm-cc=([A-Z]{2})/)?.[1];
  if (cc) {
    let name = ''; try { name = new Intl.DisplayNames(['en'], { type: 'region' }).of(cc) || ''; } catch {}
    if (cc === 'TR') name = 'Turkey';
    return COUNTRIES.includes(name) ? name : 'Other';
  }
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return tz === 'Asia/Dhaka' ? 'Bangladesh' : tz === 'Asia/Kuala_Lumpur' ? 'Malaysia' : tz.startsWith('America/') ? 'United States' : '';
};

export default function Checkout() {
  const s = useStore();
  const router = useRouter();
  const [f, setF] = useState<Form>({ name: '', email: '', phone: '', country: '', address: '', city: '', zip: '', state: '' });
  const [pay, setPay] = useState('cod');
  const [trx, setTrx] = useState('');
  const [useCredit, setUseCredit] = useState(true);
  const [code, setCode] = useState(''); // coupon applied
  const [codeIn, setCodeIn] = useState(''); // coupon being typed
  const [q, setQ] = useState<Q | null>(null);
  const [qFor, setQFor] = useState('');
  const [qFail, setQFail] = useState(''); // inputs whose quote failed to load
  const [retry, setRetry] = useState(0); // which inputs the shown quote was made for
  const [err, setErr] = useState('');
  const [busy, start] = useTransition();
  const lines = s.bag.filter(l => !l.off).map(({ slug, qty }) => ({ slug, qty }));
  const key = JSON.stringify(lines);

  // Autofill: saved details on this device, then the signed-in account, then a guess from the time zone.
  useEffect(() => {
    let saved: Partial<Form> = {}; try { saved = JSON.parse(localStorage.getItem('pm-details') || '{}'); } catch {}
    const filled = Object.fromEntries(Object.entries(saved).filter(([, v]) => v)); // a saved blank must not wipe the guess
    setF(x => ({ ...x, country: guessCountry(), ...filled }));
  }, []);
  // The quote re-checks credit when the email changes, so the total shown matches the order placed.
  const mail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.trim()) ? f.email.trim().toLowerCase() : '';
  // Until the quote for the current inputs arrives, the shown total may be stale, so ordering waits.
  const want = JSON.stringify([key, f.country, useCredit, mail, code]);
  const fresh = !!q && qFor === want;
  useEffect(() => {
    if (!lines.length || !f.country) { setQ(null); return; }
    let live = true;
    checkoutQuote({ lines, country: f.country, useCredit, email: mail || undefined, coupon: code || undefined }).then(r => {
      if (!live) return; setQ(r); setQFor(want); setQFail('');
      if (!r.pay.some(m => m.id === pay)) setPay(r.pay[0].id);
      if (r.me) { const a = (r.me.address || {}) as Record<string, string>; setF(x => ({ ...x, email: x.email || r.me!.email || '', name: x.name || r.me!.name, phone: x.phone || r.me!.phone || '', address: x.address || a.address || '', city: x.city || a.city || '', zip: x.zip || a.zip || '', state: x.state || a.state || '' })); }
    }).catch(e => { console.error('quote failed', e); if (live) setQFail(want); });
    return () => { live = false; };
  }, [key, f.country, useCredit, mail, code, retry]); // eslint-disable-line react-hooks/exhaustive-deps

  // Checkout charges the delivery country's currency; switch the whole shop (header, bag) to it so every price matches.
  useEffect(() => { if (q?.cur && q.cur !== s.cur && s.rates[q.cur as Currency] > 0) s.setCur(q.cur as Currency); }, [q?.cur]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!lines.length) return <div className="empty page-empty"><h2>{s.t('Your bag is empty')}</h2><p>{s.t('Add something you love, then come back.')}</p><Link className="btn" href="/shop">{s.t('Continue shopping')}</Link></div>;
  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const money = (n: number) => formatAmount(n, (q?.cur || 'USD') as Currency);
  return (
    <form className="co" onSubmit={e => {
      e.preventDefault(); setErr('');
      if (!fresh) return;
      start(async () => {
        try { localStorage.setItem('pm-details', JSON.stringify(f)); } catch {}
        const r = await checkout({ lines, ...f, pay, useCredit, trx, coupon: q?.coupon || undefined });
        if ('error' in r && r.error) { setErr(r.error); return; }
        lines.forEach(l => s.setQty(l.slug, 0));
        const o = r as { id: string; pay: boolean };
        if (o.pay) location.assign(`/api/pay/start?o=${o.id}`); else router.push(`/order/${o.id}`);
      });
    }}>
      <div className="panel">
        <div className="kicker">{s.t('Checkout')}</div><h2>{s.t('Delivery details')}</h2>
        <p className="muted" style={{ fontSize: '.9rem' }}>{s.t('No account needed. Your email becomes your account, so you can track the order and use store credit later.')}</p>
        <div className="two"><div className="field"><label htmlFor="n">{s.t('Full name')}</label><input id="n" autoComplete="name" required value={f.name} onChange={set('name')} /></div>
          <div className="field"><label htmlFor="t">{s.t('Phone')}</label><input id="t" type="tel" autoComplete="tel" required inputMode="tel" pattern="[+0-9 ()\-]{6,}" title="Digits only, like +60 12 345 6789" placeholder="+60 12 345 6789" value={f.phone} onChange={set('phone')} /></div></div>
        <div className="field"><label htmlFor="e">{s.t('Email')}</label><input id="e" type="email" autoComplete="email" required value={f.email} onChange={set('email')} /></div>
        <div className="field"><label htmlFor="c">{s.t('Country')}</label><select id="c" autoComplete="country-name" required value={f.country} onChange={set('country')}><option value="">{s.t('Choose…')}</option>{COUNTRIES.map(c => <option key={c}>{c}</option>)}</select></div>
        <div className="field"><label htmlFor="a">{s.t('Address')}</label><input id="a" autoComplete="street-address" required value={f.address} onChange={set('address')} /></div>
        <div className="two"><div className="field"><label htmlFor="ci">{s.t('City')}</label><input id="ci" autoComplete="address-level2" value={f.city} onChange={set('city')} /></div>
          <div className="field"><label htmlFor="z">{s.t('Postcode')}</label><input id="z" autoComplete="postal-code" value={f.zip} onChange={set('zip')} /></div></div>
        {!['Bangladesh', 'Malaysia'].includes(f.country) && <div className="field"><label htmlFor="st">{s.t('State or province')}</label><input id="st" autoComplete="address-level1" value={f.state} onChange={set('state')} required={f.country === 'United States'} /></div>}
        {q && <><h3>{s.t('Payment')}</h3><div className="pays">{q.pay.map(m => <label key={m.id} className="pay"><input type="radio" name="pay" value={m.id} checked={pay === m.id} onChange={() => setPay(m.id)} /><span>{s.t(m.label)}{!m.manual && <small>{s.t(m.note)}</small>}</span></label>)}
          {q.soon.map(m => <label key={m.id} className="pay soon" aria-disabled="true"><input type="radio" disabled /><span>{s.t(m.label)}<small>{s.t('Coming soon')}</small></span></label>)}</div>
          {(() => { const m = q.pay.find(x => x.id === pay); if (!m?.manual) return pay !== 'cod' && <p className="muted" style={{ fontSize: '.85rem' }}>{s.t('Online payment opens after you place the order.')}</p>;
            return <div className="manual-pay"><p style={{ whiteSpace: 'pre-line' }}><b>{s.t('Send {x} to:', { x: money(q.total) })}</b><br />{m.note}</p>
              <div className="field"><label htmlFor="trx">{s.t('Transaction ID')}</label><input id="trx" required value={trx} onChange={e => setTrx(e.target.value)} placeholder="e.g. 9JK3L2M8PQ" /></div>
              <p className="muted" style={{ fontSize: '.82rem' }}>{s.t('We confirm the payment and then ship your order.')}</p></div>; })()}</>}
      </div>
      <div className="panel">
        <h3>{s.t('Your order')}</h3>
        {lines.map(l => { const p = s.products[l.slug]; return <div className="line-item" key={l.slug}><div className="thumb"><Art p={p} /></div><div style={{ flex: 1 }}>{p.name}<div className="muted" style={{ fontSize: '.8rem' }}>{p.sub} · ×{l.qty}</div></div></div>; })}
        {q ? <>
          <div className="sum-row"><span>{s.t('Items')}</span><span>{money(q.subtotal)}</span></div>
          <div className="sum-row"><span>{s.t('Delivery')} · {q.courier}</span><span>{q.shipping ? money(q.shipping) : s.t('Free')}</span></div>
          <div className="coupon-row"><input aria-label={s.t('Discount code')} placeholder={s.t('Discount code')} value={codeIn} onChange={e => setCodeIn(e.target.value.toUpperCase())} />
            {code ? <button type="button" className="btn ghost sm" onClick={() => { setCode(''); setCodeIn(''); }}>{s.t('Remove')}</button> : <button type="button" className="btn ghost sm" disabled={!codeIn.trim()} onClick={() => setCode(codeIn.trim())}>{s.t('Apply')}</button>}</div>
          {code && fresh && q.couponError && <p className="err" style={{ margin: 0 }}>{s.t(q.couponError)}</p>}
          {q.discount > 0 && <div className="sum-row"><span>{s.t('Code')} {q.coupon}</span><span>−{money(q.discount)}</span></div>}
          {q.available > 0 && <label className="toggle"><span>{s.t('Use store credit ({x} available)', { x: money(q.available) })}</span><input type="checkbox" checked={useCredit} onChange={e => setUseCredit(e.target.checked)} /></label>}
          {q.credit > 0 && <div className="sum-row"><span>{s.t('Store credit')}</span><span>−{money(q.credit)}</span></div>}
          <div className="sum-row total"><span>{s.t('Total')}</span><span>{money(q.total)}</span></div>
          {/* The shop shows prices in the visitor's chosen currency; checkout charges the delivery country's currency. Show both so they match. */}
          {q.cur !== s.cur && s.rates[q.cur as Currency] > 0 && s.rates[s.cur] > 0 && <p className="cur-note">{s.t('≈ {x} in {c}. You pay in {p}, the currency of your delivery country.', { x: formatAmount(q.total / s.rates[q.cur as Currency] * s.rates[s.cur], s.cur), c: s.cur, p: q.cur })}</p>}
          {q.saved > 0 && <div className="saved"><span>{s.t('You save')}</span><b>{money(q.saved)}</b></div>}
          {q.reward > 0 && <p className="earn">{s.t('You earn {x} in store credit when this order is delivered.', { x: money(q.reward) })}</p>}
          {s.pre ? <p className="pre-line">{s.t('Pre-order')} · {s.t(s.pre)}. {s.t('Delivery takes {a}–{b} days after it ships.', { a: q.days[0], b: q.days[1] })}</p>
            : <p className="muted" style={{ fontSize: '.85rem' }}>{s.t('Arrives in {a}–{b} days.', { a: q.days[0], b: q.days[1] })}</p>}
        </> : <p className="muted">{s.t('Choose your country to see delivery and total.')}</p>}
        {err && <p className="err">{s.t(err)}</p>}
        {qFail === want && <p className="err">{s.t('We could not load your total.')} <button type="button" style={{ background: 'none', border: 0, padding: 0, color: 'inherit', textDecoration: 'underline', cursor: 'pointer', font: 'inherit' }} onClick={() => { setQFail(''); setRetry(n => n + 1); }}>{s.t('Try again')}</button></p>}
        <button className="btn" disabled={busy || !fresh}>{s.t(busy ? 'Placing order…' : 'Place order')}</button>
      </div>
    </form>
  );
}
