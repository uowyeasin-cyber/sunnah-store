import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import { db } from '@/lib/db';
import { getSettings } from '@/lib/catalog';
import { formatAmount, type Currency } from '@/lib/money';
import { barcodeSvg, qrSvg } from '@/lib/codes';
import ReceiptActions from '@/components/ReceiptActions';
import RememberOrder from '@/components/RememberOrder';
import Timeline from '@/components/Timeline';
import ReturnForm from '@/components/ReturnForm';
import PurchaseEvent from '@/components/PurchaseEvent';
import { getSeo } from '@/lib/seo';
import { RETURN_REASONS, returnWindowOpen } from '@/lib/returns';
import { DELIVERED } from '@/lib/tracking';
import { getDict } from '@/lib/catalog';
import { isLang, makeT, type Lang } from '@/lib/i18n';


export const instant = false;
export const metadata = { title: 'Your receipt', robots: { index: false } };

async function Receipt({ params }: { params: Promise<{ id: string; lang: string }> }) {
  const { id, lang: l } = await params;
  const lang: Lang = isLang(l) ? l : 'en';
  const [o, s, dict, seo] = await Promise.all([db.order.findUnique({ where: { id }, include: { lines: true, returns: { orderBy: { createdAt: 'desc' } } } }), getSettings(lang), getDict(lang), getSeo()]);
  const t = makeT(dict);
  if (!o) notFound();
  const cur = o.currency as Currency;
  const f = (n: unknown) => formatAmount(Number(n), cur);
  const url = `${process.env.SITE_URL || ''}/order/${o.id}`;
  const [qr, bar] = await Promise.all([qrSvg(url || o.no), Promise.resolve(barcodeSvg(o.no))]);
  const day = (d: Date | null) => d?.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' });
  const addr = o.address as Record<string, string>;
  return (
    <div className="receipt">
      <div className="top"><div><div className="kicker">{s.store.name} · {t('Receipt')}</div><h2>{t('Thank you, {x}.', { x: o.name.split(' ')[0] })}</h2></div><div className="num" style={{ textAlign: 'right' }}>{o.no}<br /><small>{o.createdAt.toLocaleString('en-US')}</small></div></div>
      <div className="body">
        <RememberOrder id={o.id} />
        {!['failed', 'cancelled', 'refunded'].includes(o.payStatus) && <PurchaseEvent no={o.no} value={Number(o.total)} currency={o.currency} gadsSend={seo.pixels.gads && seo.pixels.gadsLabel ? `${seo.pixels.gads}/${seo.pixels.gadsLabel}` : ''} />}
        <ReceiptActions url={`/order/${o.id}`} title={`${s.store.name} · ${o.no}`} t={{ download: t('Download PDF'), share: t('Share'), copied: t('Link copied'), whatsapp: 'WhatsApp' }} />
        <div className="codes"><div className="qr" dangerouslySetInnerHTML={{ __html: qr }} /><div className="bar" dangerouslySetInnerHTML={{ __html: bar }} /></div>
        <div className="kv">
          <div><span>{t('Order number')}</span>{o.no}</div><div><span>{t('Order ID')}</span><code className="oid">{o.id}</code></div>
          <div><span>{t('Payment')}</span>{o.payMethod === 'cod' ? t('Cash on delivery') : o.payMethod.replace(/^m-/, '').toUpperCase()} · {t(o.payStatus === 'paid' ? 'Paid' : o.payStatus === 'cod' ? 'Pay on delivery' : 'Awaiting payment')}</div>
          {o.preorder && o.status === 0 ? <div><span>{t('Pre-order')}</span>{t(o.preorder)}</div> : <div><span>{t('Arrives')}</span>{day(o.etaFrom)} – {day(o.etaTo)}</div>}
          <div><span>{t('Courier')}</span>{o.courier}{o.trackingNo && ` · ${o.trackingNo}`}</div>
          <div><span>{t('Deliver to')}</span>{addr.address}{addr.city && `, ${addr.city}`} {addr.zip}, {o.country}</div>
        </div>
        {o.payMethod.startsWith('m-') && o.payStatus === 'pending' && <div className="paynow"><p>{t('We received your transaction ID {x} and will confirm the payment soon.', { x: o.payRef })}</p></div>}
        {o.payMethod !== 'cod' && !o.payMethod.startsWith('m-') && (o.payStatus === 'pending' || o.payStatus === 'failed') && <div className="paynow"><p>{t(o.payStatus === 'failed' ? 'The payment did not go through.' : 'This order is waiting for payment.')}</p><a className="btn brass" href={`/api/pay/start?o=${o.id}`}>{t('Pay {x} now', { x: f(o.total) })}</a></div>}
        <div className="tear" />
        {o.lines.map(l => <div className="sum-row" key={l.id}><span>{l.qty} × {l.name}</span><span>{f(Number(l.full) * l.qty)}</span></div>)}
        {Number(o.saved) > 0 && <div className="sum-row"><span>{t('Offers')}</span><span>−{f(o.saved)}</span></div>}
        <div className="sum-row"><span>{t('Delivery')}</span><span>{Number(o.shipping) ? f(o.shipping) : t('Free')}</span></div>
        {Number(o.creditUsed) > 0 && <div className="sum-row"><span>{t('Store credit')}</span><span>−{f(o.creditUsed)}</span></div>}
        <div className="sum-row total"><span>{t('Total')}</span><span>{f(o.total)}</span></div>
        {Number(o.saved) > 0 && <div className="saved"><span>{t('You saved')}</span><b>{f(o.saved)}</b></div>}
        {Number(o.rewardEarned) > 0 && <p className="earn">{t('You earn {x} in store credit when this arrives.', { x: f(o.rewardEarned) })}</p>}
        <div className="tear" />
        <h3>{t('Tracking')}</h3>
        <Timeline status={o.status} events={o.events as { at: string; step: number; note: string }[]} rider={o.status >= 5 && o.riderPhone ? { name: o.riderName, phone: o.riderPhone } : null} t={t} />
        {(() => {
          const r = o.returns[0];
          if (r) return <p className="muted" style={{ fontSize: '.9rem' }}>{t('Return request')}: {t(r.reason)} · <b>{t(r.status === 'pending' ? 'Waiting for review' : r.status === 'approved' ? 'Approved' : 'Declined')}</b>{r.adminNote && ` · ${r.adminNote}`}</p>;
          return o.status === DELIVERED && returnWindowOpen(o.events as { at: string; step: number }[], DELIVERED) ? <ReturnForm orderId={o.id} reasons={RETURN_REASONS} /> : null;
        })()}
        <p className="muted" style={{ fontSize: '.85rem' }}>{t('A copy was emailed to {x}. Keep this page; it updates as the courier moves your order.', { x: o.email })}</p>
      </div>
    </div>
  );
}

export default function OrderPage({ params }: PageProps<'/[lang]/order/[id]'>) {
  return <div className="wrap view"><Suspense fallback={<div style={{ minHeight: '70vh' }} />}><Receipt params={params} /></Suspense></div>;
}
