'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { channel } from '@/lib/channels';

const str = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();
const back = (m: string): never => redirect(`/admin/channels?note=${encodeURIComponent(m)}`);

// Opens the marketplace's own "allow this app" page; it sends the seller back to /api/channels/callback.
export async function linkShop(fd: FormData) {
  const ch = channel(str(fd, 'id'));
  await requireAdmin('channels', 'linkShop', ch?.id || '');
  const { connector } = await import('@/lib/connectors');
  const c = ch ? await connector(ch.api) : null;
  if (!ch || !c?.authUrl) back('This channel cannot be linked here yet.');
  const { loadKeys } = await import('@/lib/keys');
  await loadKeys(true);
  if (!c!.ready(ch!)) back(`Add the ${c!.keysNeeded(ch!)} in Connections → Marketplaces first.`);
  const site = process.env.SITE_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : 'http://localhost:3000');
  redirect(c!.authUrl!(ch!, `${site}/api/channels/callback`, ch!.id));
}

export async function unlinkShop(fd: FormData) {
  const ch = channel(str(fd, 'id'));
  await requireAdmin('channels', 'unlinkShop', ch?.id || '');
  if (ch) { const { unlink } = await import('@/lib/chanToken'); await unlink(ch); }
  revalidatePath('/admin/channels');
}

export async function syncNow(fd: FormData) {
  const id = str(fd, 'id');
  await requireAdmin('channels', 'syncChannels', id);
  const { syncChannels } = await import('@/lib/channelSync');
  const r = await syncChannels(id || undefined);
  back(r.linked ? `${r.synced} listings updated · ${r.added} new orders${r.errors.length ? ` · ${r.errors[0]}` : ''}` : 'No linked shop to sync.');
}
