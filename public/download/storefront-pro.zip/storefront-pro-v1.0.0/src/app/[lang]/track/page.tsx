import Link from 'next/link';
import { Suspense } from 'react';
import { db } from '@/lib/db';
import { currentCustomer } from '@/lib/auth';
import { formatAmount, type Currency } from '@/lib/money';
import { STEPS } from '@/lib/tracking';
import TrackForm from '@/components/TrackForm';
import DeviceOrders from '@/components/DeviceOrders';
import { getDict } from '@/lib/catalog';
import { isLang, makeT, type Lang } from '@/lib/i18n';


export const metadata = { title: 'Track order' };

// Signed-in customers also see their orders and store credit history here.
async function Mine({ lang }: { lang: Lang }) {
  const [c, dict] = await Promise.all([currentCustomer(), getDict(lang)]);
  const t = makeT(dict);
  if (!c) return <p className="muted" style={{ fontSize: '.9rem' }}>{t('Signed in? Your orders and store credit show here. Sign in from the account icon.')}</p>;
  const [orders, ledger] = await Promise.all([
    db.order.findMany({ where: { customerId: c.id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    db.creditEntry.findMany({ where: { customerId: c.id }, orderBy: { createdAt: 'desc' }, take: 50 }),
  ]);
  const cur = c.currency as Currency;
  return <>
    <section className="panel"><div className="kicker">{t('Your orders')}</div>
      {orders.length ? orders.map(o => <div className="sum-row" key={o.id}><Link href={`/order/${o.id}`}>{o.no}</Link><span>{t(STEPS[o.status])}</span><span>{formatAmount(Number(o.total), o.currency as Currency)}</span></div>) : <p className="muted">{t('No orders yet.')}</p>}
    </section>
    <section className="panel"><div className="kicker">{t('Store credit')}</div><h3 style={{ margin: '6px 0 12px' }}>{formatAmount(Number(c.credit), cur)}</h3>
      {ledger.map(e => <div className="sum-row" key={e.id}><span>{t(e.note)}<br /><small className="muted">{e.createdAt.toLocaleDateString('en-US')}</small></span><span>{Number(e.amount) > 0 ? '+' : '−'}{formatAmount(Math.abs(Number(e.amount)), cur)}</span></div>)}
    </section>
  </>;
}

export default async function Track({ params }: PageProps<'/[lang]/track'>) {
  const { lang: l } = await params;
  const lang: Lang = isLang(l) ? l : 'en';
  const t = makeT(await getDict(lang));
  return <div className="wrap view" style={{ display: 'grid', gap: 24, maxWidth: 640, margin: '48px auto' }}>
    <DeviceOrders />
    <section className="panel"><div className="kicker">{t('Orders')}</div><h2>{t('Track your order')}</h2><TrackForm /></section>
    <Suspense fallback={null}><Mine lang={lang} /></Suspense>
  </div>;
}
