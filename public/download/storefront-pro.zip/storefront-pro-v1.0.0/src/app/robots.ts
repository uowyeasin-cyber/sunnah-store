import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const site = process.env.SITE_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : 'http://localhost:3000');
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/api/', '/checkout', '/order/', '/account', '/go/'] }], sitemap: `${site}/sitemap.xml` };
}
